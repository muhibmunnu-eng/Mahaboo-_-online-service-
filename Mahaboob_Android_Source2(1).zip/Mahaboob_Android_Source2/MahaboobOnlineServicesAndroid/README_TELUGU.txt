MAHABOOB ONLINE SERVICES - Android project starter

ఈ ZIP ఒక Native Android Studio source project. ఇది APK కాదు; Play Storeలో ప్రచురించడానికి సిద్ధమైన build కూడా కాదు.

ప్రస్తుతం ఇందులో:
- తెలుగు + English ప్రాథమిక UI
- Customer service ఎంపికలు
- Customer request form
- Submit చేసినప్పుడు 9542084119 WhatsApp chatలో pre-filled message తెరుస్తుంది (కస్టమర్ Send నొక్కాలి)
- Admin Login screen రూపకల్పన

ఇంకా చేయాల్సినవి:
1. Firebase project సృష్టించి Android appకు google-services.json జోడించాలి.
2. Firebase Authenticationతో Admin login భద్రపరచాలి.
3. Firestore databaseలో customer requests సేవ్ చేయాలి.
4. Admin dashboardలో అన్ని customer requests చూపాలి.
5. WhatsApp Business Platform/APIని అధికారికంగా సెటప్ చేసి approved templatesతో notifications ఆటోమేట్ చేయాలి.
6. Privacy Policy, Data Safety, app icon, screenshots, testing, signed AAB సిద్ధం చేయాలి.
7. Google Play Developer account ద్వారా ప్రచురణ.

ముఖ్యం:
- ఈ starterలో customer data cloudలో save కాదు.
- WhatsAppకు message draft మాత్రమే తెరుస్తుంది; ఆటోమేటిక్‌గా పంపదు.
- Admin login ఇంకా activate కాలేదు. PINను source codeలో hard-code చేయవద్దు.
- Aadhaar/OTP/bank PIN/passwordలను యాప్‌లో సేకరించవద్దు.
- Build చేయడానికి Android Studio ఉన్న computer అవసరం. కేవలం Android phoneతో ఈ projectను నేరుగా APKగా compile చేయడం సాధారణంగా సాధ్యం కాదు.

Package: in.mahaboob.onlineservices
App ID: in.mahaboob.onlineservices
