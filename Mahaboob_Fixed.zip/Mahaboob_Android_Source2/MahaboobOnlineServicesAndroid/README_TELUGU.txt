MAHABOOB ONLINE SERVICES ANDROID PROJECT

ఈ ప్రాజెక్ట్‌ను GitHub repository లో upload చేయండి.

ముఖ్యమైన విషయాలు:
1. settings.gradle.kts ఉన్న ప్రాజెక్ట్ ఫోల్డర్‌ను repository లో ఉంచండి.
2. .github/workflows/main.yml ఫైల్ కూడా repository లో ఉండాలి.
3. GitHub లో Actions tab తెరిచి “Build Mahaboob Online Services APK” workflow ఎంచుకోండి.
4. Run workflow నొక్కండి.
5. Build పూర్తయిన తర్వాత workflow run లో Artifacts కింద Mahaboob-Online-Services-APK download చేయండి.

Build కోసం JDK 17 మరియు Gradle 8.9 workflow లో ఆటోమేటిక్‌గా setup అవుతాయి.
ఈ ZIP source project మాత్రమే; APK build విజయవంతమైన తర్వాత GitHub Actions Artifacts లో APK వస్తుంది.
